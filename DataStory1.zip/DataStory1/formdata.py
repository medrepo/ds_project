#! python

import numpy as np

# function to calculate sum of values per year
def yearlysum(frm, var, group):
    res = frm.groupby(var.dt.year)[group].sum()
    res = res.to_frame()
    
    return res


# function to calculate the percentage of value over total upto 2 decimal places
def perc(num, tot):
    prc = np.round(((num / tot) * 100), decimals=2)
    
    return prc


